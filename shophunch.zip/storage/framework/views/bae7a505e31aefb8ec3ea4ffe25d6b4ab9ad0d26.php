<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Welcome!')); ?>

                </div>
            </div>
            <div class="card mt-5">
            <div class="card-header"><?php echo e(__('Details')); ?></div>
            <div class="card-body">
                <div id="columnchart_material" style="width: 700px; height: 500px;"></div>
            </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Year', 'Sales', 'Invetories', 'Expenses'],
            ['2023', <?php echo e($data['countSales']); ?>, <?php echo e($data['countInventory']); ?>, <?php echo e($data['countExpenses']); ?>]
        ]);

        var options = {
          chart: {
            title: 'Shop Stats',
            subtitle: 'Sales, Expenses and profit',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ainigma Dev\shop_app\resources\views/home.blade.php ENDPATH**/ ?>