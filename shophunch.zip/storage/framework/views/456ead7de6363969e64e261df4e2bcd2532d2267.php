

<?php $__env->startSection('content'); ?>
<section class="pt-5">
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
            <h1>Store</h1>
                <div class="card">
                    <div class="card-header"><?php echo e(__('Store info')); ?></div>

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">Store Name</th>
                                    <th scope="col">Store Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $storeDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key->store_name); ?></td>
                                    <td><?php echo e($key->store_address); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    </div>
                </div>
            </div>    
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
                <?php endif; ?>  
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>  
                <div class="card">
                    <div class="card-header"><?php echo e(__('Add Store')); ?></div>
                    <!-- <div class="card-body">
                       <h5>Cannot make anymore store!</h5>
                    </div> -->
                    <div class="card-body">
                        <form action="<?php echo e(route('addStore')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col">
                                <input type="text" class="form-control" name="storeName" placeholder="Store Name">
                                </div>
                                <div class="col">
                                <input type="text" class="form-control" name="storeAddress" placeholder="Store Address">
                                </div>
                                <div class="col-auto">
                                    <button type="submit" class="btn btn-primary mb-2">Add</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
            </div>    
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ainigma Dev\shop_app\resources\views/store.blade.php ENDPATH**/ ?>